
xpath_main <- Sys.getenv("PATH_MY_MAIN_DATA")
xpath_nlp <- file.path(xpath_main, "analysis", "nlp", "_assets")

library(RMySQL)
drv <- dbDriver("MySQL")
xdbsock <- ""

xdbuser <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_USER")
xpw     <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PW")
xdbname <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_DBNAME")
xdbhost <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_HOST")
xdbport <- as.integer( Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PORT") )

con <- dbConnect(drv, user=xdbuser, password=xpw, dbname=xdbname, host=xdbhost, port=xdbport, unix.sock=xdbsock)
dbListTables(con)

# Getting recipe table

clean_df <-dbGetQuery(con, "SELECT * FROM spoonacular_clean")
dim(clean_df)

# boil 
cond1 <- grepl("boil", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("pot", clean_df$instructions, ignore.case = TRUE)
cond3 <- grepl("cover", clean_df$instructions, ignore.case = TRUE)

boil <- cond1 | cond2 | cond3

# sauce
cond1 <- grepl("tomato", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("celery", clean_df$instructions, ignore.case = TRUE)
cond3 <- grepl("shallot", clean_df$instructions, ignore.case = TRUE)
cond4 <- grepl("sauce", clean_df$instructions, ignore.case = TRUE)
cond5 <- grepl("saucepan", clean_df$instructions, ignore.case = TRUE)

sauce <- cond1 | cond2 | cond3 | cond4 | cond5

# salad 
cond1 <- grepl("toss", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("drizzle", clean_df$instructions, ignore.case = TRUE)
cond3 <- grepl("dress", clean_df$instructions, ignore.case = TRUE)
cond4 <- grepl("combine", clean_df$instructions, ignore.case = TRUE)
cond5 <- grepl("arugula", clean_df$instructions, ignore.case = TRUE)
cond6 <- grepl("salad", clean_df$instructions, ignore.case = TRUE)

salad <- cond1 | cond2 | cond3 | cond4 | cond5 | cond6

# bread 
cond1 <- grepl("bread", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("dough", clean_df$instructions, ignore.case = TRUE)
cond3 <- grepl("flour", clean_df$instructions, ignore.case = TRUE)

bread <- cond1 | cond2 | cond3

# roast
cond1 <- grepl("roast", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("oven", clean_df$instructions, ignore.case = TRUE)
cond3 <- grepl("bake", clean_df$instructions, ignore.case = TRUE)
cond4 <- grepl("sheet", clean_df$instructions, ignore.case = TRUE)

roast <- cond1 | cond2 | cond3 | cond4

# spice
cond1 <- grepl("onion", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("garlic", clean_df$instructions, ignore.case = TRUE)

spice <- cond1 | cond2

# pan-fry 
cond1 <- grepl("skillet", clean_df$instructions, ignore.case = TRUE)
cond2 <- grepl("brown", clean_df$instructions, ignore.case = TRUE)

panfry <- cond1 & cond2

### evaluate categories 
thirdTry_df <- data.frame(boil = boil, sauce = sauce, salad = salad, 
                          bread = bread, roast = roast, spice = spice, 
                          panfry = panfry)

logic_vec <- apply(thirdTry_df, 1, sum)
hist(logic_vec)

### write csv

xpath_lin <- file.path(xpath_main, "analysis", "linear")
write.csv(thirdTry_df, file.path(xpath_lin, "_assets", "thirdTry_df.csv"), row.names = FALSE)



