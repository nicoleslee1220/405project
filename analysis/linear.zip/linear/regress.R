
xpath_main <- Sys.getenv("PATH_MY_MAIN_DATA")
xpath_lin <- file.path(xpath_main, "analysis", "linear")

library(RMySQL)
drv <- dbDriver("MySQL")
xdbsock <- ""

xdbuser <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_USER")
xpw     <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PW")
xdbname <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_DBNAME")
xdbhost <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_HOST")
xdbport <- as.integer( Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PORT") )

con <- dbConnect(drv, user=xdbuser, password=xpw, dbname=xdbname, host=xdbhost, port=xdbport, unix.sock=xdbsock)

clean_df <- dbGetQuery(con, "SELECT * FROM spoonacular_clean")

#####
# prep clean_df for regression
names(clean_df)
library(dplyr)

regress_df <- clean_df %>% select(-c(DT, recipeID , sourceName, instructions)) 
regress_df[1:9] <- lapply(regress_df[1:9], as.logical)
regress_df[c("gaps", "spiciness")] <- lapply(regress_df[c("gaps", "spiciness")], as.factor)
regress_df <- regress_df %>% select(-c(cheap, sustainable)) %>% select(-veryHealthy)
  # cheap, sustainable are all FALSE 
  # veryHealthy is highly correlated and unhelpful
str(regress_df)

##### 

# use just diet categorical 
diet_df <- regress_df %>% select(healthScore, vegetarian:dairyFree)

diet_mod <- lm(healthScore ~ ., data = diet_df)
  # intercept is unrestricted diet 
diet_mod2 <- update(diet_mod, .~.-vegetarian-glutenFree, data = diet_df)

# use just keywords 
category_df <- cbind(regress_df$healthScore, 
                    read.csv(file.path(xpath_lin, "_assets", "category_df.csv"), 
                             header = TRUE, sep = ","))
names(category_df)[1] <- "healthScore"

category_mod <- lm(healthScore ~ ., data = category_df)
category_mod2 <- update(category_mod, .~.-sauce-salad, data = category_df)
  # meat highly valued 

# combine both
tot_df <- cbind(regress_df, category_df)
tot_mod <- lm(healthScore ~ ., data = tot_df)

tot_mod2 <- update(tot_mod, .~.-vegetarian-vegan-glutenFree-veryPopular-lowFodmap-gaps-aggregateLikes, data = tot_df)
tot_mod3 <- update(tot_mod2, .~.-readyInMinutes-savoriness-spiciness-bitterness, data = tot_df)
tot_mod4 <- update(tot_mod3, .~.-weightWatcherSmartPoints, data = tot_df)
  # too highly correlated
tot_mod5 <- update(tot_mod4, .~.-sweetness-saltiness-sourness, data = tot_df)
  # estimates are too low to carry meaning 
tot_mod6 <- update(tot_mod5, .~.-fattiness-boil, data = tot_df)
# test <- update(tot_mod6, .~.-pricePerServing, data = tot_df)
  # pricePerServing is incredibly significant: makes R^2 from 0.3298 -> 0.08868
    # makes salad significant; overpriced per serving
  # goes back to premade clusters
tot_mod7 <- update(tot_mod6, .~.-sauce-roast-meat, data = tot_df)
  # get rid of low ANOVA
    # AIC, BIC increase slightly and R^2 decreases slightly but now fewer predictors 
  # chisq test says there is an interaction between dairyFree and dairy 
    # dairy has lower ANOVA Sum Sq -> tot_mod8
    # implies cheese and butter are very unhealthy
# test2 <- update(tot_mod7, .~.-dairy, data = tot_df)
  # estimates do not make sense
# test3 <- update(tot_mod7, .~.-salad-bread, data = tot_df)
  # AIC is higher

# test interaction between dairyFree and dairy 
chisq.test(tot_mod7$model$dairyFree, tot_mod7$model$dairy)

inter_mod <- lm(healthScore ~ dairyFree:dairy, data = tot_df)
library(effects)
plot(allEffects(inter_mod), ask = FALSE)

# remove dairy variable since dairyFree implies dairy 
### FINAL MODEL
tot_mod8 <- update(tot_mod7, .~.-dairy, data = tot_df)

##### extra diagnostics

tot_mod9 <- lm(healthScore ~ dairyFree + pricePerServing, data = tot_df)
AIC(tot_mod9); BIC(tot_mod9)
AIC(tot_mod8); BIC(tot_mod8)

# test correlation between pricePerServing and meat 
test_mod <- lm(healthScore ~ pricePerServing + meat, data = tot_df)
vif(test_mod)
  # not correlated
