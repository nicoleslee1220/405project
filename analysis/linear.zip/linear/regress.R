
xpath_main <- Sys.getenv("PATH_MY_MAIN_DATA")
xpath_lin <- file.path(xpath_main, "analysis", "linear")

library(RMySQL)
drv <- dbDriver("MySQL")
xdbsock <- ""

xdbuser <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_USER")
xpw     <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PW")
xdbname <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_DBNAME")
xdbhost <- Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_HOST")
xdbport <- as.integer( Sys.getenv("MAS405_AWS_PROJ_DB_ROUSER_PORT") )

con <- dbConnect(drv, user=xdbuser, password=xpw, dbname=xdbname, host=xdbhost, port=xdbport, unix.sock=xdbsock)

clean_df <- dbGetQuery(con, "SELECT * FROM spoonacular_clean")

#####
# prep clean_df for regression
names(clean_df)
library(dplyr)

regress_df <- clean_df %>% select(-c(DT, recipeID , sourceName, instructions)) 
regress_df[1:9] <- lapply(regress_df[1:9], as.logical)
regress_df[c("gaps", "spiciness")] <- lapply(regress_df[c("gaps", "spiciness")], as.factor)
regress_df <- regress_df %>% select(-c(cheap, sustainable)) %>% select(-veryHealthy)
  # cheap, sustainable are all FALSE 
  # veryHealthy is highly correlated and unhelpful
str(regress_df)

clean_mod <- lm(healthScore ~ ., data = regress_df)

##### second try 

# use just diet categorical 
diet_df <- regress_df %>% select(healthScore, vegetarian:dairyFree)

diet_mod <- lm(healthScore ~ ., data = diet_df)
  # intercept is unrestricted diet 
diet_mod2 <- update(diet_mod, .~.-vegetarian-glutenFree, data = diet_df)

# use just keywords 
keyword_df <- cbind(regress_df$healthScore, 
                    read.csv(file.path(xpath_lin, "_assets", "keyword_df.csv"), 
                             header = TRUE, sep = ","))
names(keyword_df)[1] <- "healthScore"
key_mod <- lm(healthScore ~ ., data = keyword_df)

# combine both
tot_df <- cbind(regress_df, keyword_df)
tot_mod <- lm(healthScore ~ ., data = tot_df)

##### third try

thirdTry_df <- cbind(regress_df$healthScore, 
                     read.csv(file.path(xpath_lin, "_assets", "thirdTry_df.csv"), 
                              header = TRUE, sep = ","))
names(thirdTry_df)[1] <- "healthScore"
thirdTry_df <- cbind(thirdTry_df, keyword_df$meat, keyword_df$vegetable, 
                     keyword_df$cheese, keyword_df$oil)
names(thirdTry_df)[9:12] <- c("meat", "vegetable", "cheese", "oil")

third_mod <- lm(healthScore ~., data = thirdTry_df)
third_mod2 <- update(third_mod, .~.-sauce-salad-panfry-oil)

# combine both 
totThird_df <- cbind(regress_df, thirdTry_df)
totThird_mod <- lm(healthScore ~., data = totThird_df)

